<?php
    echo "Hola mundo";
?>